from django.apps import AppConfig


class RaiseTicketConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'raise_ticket'
